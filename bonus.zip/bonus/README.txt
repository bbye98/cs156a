Please start with the bonus.pdf file when reviewing this
assignment. It will direct you to the remaining files in
this directory as needed.

Thank you!